# 🎬 Movie Recommendation System

This project builds a simple movie recommender using collaborative filtering (user-user) with the MovieLens 100k dataset.

## Features
- Uses Surprise library
- Trains KNN-based collaborative model
- Evaluates with RMSE
- Outputs top 5 movie recommendations for a given user

## How to Run
1. Install required packages
2. Run recommender.ipynb in Jupyter Notebook
3. Dataset is loaded from MovieLens (no local files required)
